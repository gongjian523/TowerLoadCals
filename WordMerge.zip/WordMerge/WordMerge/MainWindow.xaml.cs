﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WordMerge
{
    /// <summary>
    /// MainWindow.xaml 的交互逻辑;
    /// </summary>
    public partial class MainWindow : Window
    {
        public ObservableCollection<FileItem>  Files { get; set; }
        protected List<FileItem> list = new List<FileItem>();

        public MainWindow()
        {
            InitializeComponent();

            Files = new ObservableCollection<FileItem>();
        }

        private void btn_chose_click(object sender, EventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            dlg.Multiselect = true;//等于true表示可以选择多个文件
            dlg.DefaultExt = ".doc;.docx";
            dlg.Filter = "Word文件|*.doc;*.docx";
            if (!(bool)dlg.ShowDialog())
                return;

            List<FileItem> list = new List<FileItem>();
            list.AddRange(Files.ToList());

            for (int i = 0; i < dlg.FileNames.Count(); i++)
            {
                if (Files.Where(item => item.Name == dlg.SafeFileNames[i]).ToList().Count != 0)
                    continue;

                list.Add(new FileItem()
                {
                    Name = dlg.SafeFileNames[i],
                    Path = dlg.FileNames[i],
                    Index = Files.Count + i + 1
                });
            }

            Files = new ObservableCollection<FileItem>(list);
            fileDataGrid.DataContext = Files;
        }

        private void btn_merge_click(object sender, EventArgs e)
        {

            OpenFileDialog dlgTemp = new OpenFileDialog();
            dlgTemp.DefaultExt = ".doc;.docx";
            dlgTemp.Filter = "Word文件|*.doc;*.docx";
            if (!(bool)dlgTemp.ShowDialog())
                return;

            SaveFileDialog dlg = new SaveFileDialog();
            dlg.DefaultExt = ".doc;.docx";
            dlg.Filter = "Word文件|*.doc;*.docx";
            if (!(bool)dlg.ShowDialog())
                return;

            string temp = dlgTemp.FileName;

            list = Files.ToList().OrderBy(item => item.Index).ToList();

            string[] arr = new string[list.Count];

            for (int i = 0; i < list.Count; i++)
                arr[i] = list[i].Path;

            WordClass wordClass = new WordClass();
            wordClass.ProgressEvent += new WordClass.ProgressHandler(onRecivedProgressInfo);

            Task.Factory.StartNew(() => {
                wordClass.InsertMerge(temp, arr.ToList(), dlg.FileName);
            });
        }

        private void onRecivedProgressInfo(object sender, string e)
        {

            App.Current.Dispatcher.Invoke((Action)(() =>
            {
                if (e == "start")
                {
                    btnChonse.Visibility = Visibility.Hidden;
                    btnMerge.Visibility = Visibility.Hidden;
                    spProgress.Visibility = Visibility.Visible;
                    tbInfo.Text = "";
                    pb.Value = 0;
                }
                else if (e == "end")
                {
                    btnChonse.Visibility = Visibility.Visible;
                    btnMerge.Visibility = Visibility.Visible;
                    spProgress.Visibility = Visibility.Hidden;
                }
                else
                {
                    int index = e.LastIndexOf('\\');
                    string name = e.Substring(index + 1);
                    tbInfo.Text = name + "复制完成";
                    var it = list.Where(item => item.Path == e).First();
                    pb.Value = (list.IndexOf(it) + 1) / list.Count;
                }
            }));
        }


        private void btn_delete_click(object sender, EventArgs e)
        {
            string name = (string)((Button)sender).Tag;

            FileItem file = Files.Where(item => item.Name == name).First();

            if (file == null)
                return;

            Files.Remove(file);
        }
    }


    public class FileItem
    {
        public string Name { get; set; }

        public string Path { get; set; }

        public int Index { get; set; }
    }

}
