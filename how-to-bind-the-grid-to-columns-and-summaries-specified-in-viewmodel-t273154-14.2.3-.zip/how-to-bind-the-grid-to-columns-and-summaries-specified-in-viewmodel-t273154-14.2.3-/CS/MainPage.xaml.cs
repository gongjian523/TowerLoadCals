﻿using System.Windows.Controls;
using System.Windows;
using Model;

namespace GridMVVMBindableColumns {
    public partial class MainPage : UserControl {
        public MainPage() {
            InitializeComponent();
        }
    }
}
