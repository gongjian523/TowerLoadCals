﻿Imports System.Windows.Controls
Imports System.Windows
Imports Model

Namespace GridMVVMBindableColumns
	Partial Public Class MainPage
		Inherits UserControl

		Public Sub New()
			InitializeComponent()
		End Sub
	End Class
End Namespace
